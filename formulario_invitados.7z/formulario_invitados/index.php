<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
ini_set('error_reporting', E_ALL);

//Lista de invitados admitidos
if(file_exists("invitados.txt")){
    $strJson = file_get_contents("invitados.txt");
    $aInvitados = json_decode($strJson, true);
} else {
    $aInvitados = array();
}

if ($_POST) {
    if (isset($_POST["btnProcesar"])){
        $dni=trim($_POST["txtDNI"]);
        if (in_array($dni,array_column($aInvitados, 'dni'))){
            $found_key = array_search($dni, array_column($aInvitados, 'dni'));
            $nombre=$aInvitados[$found_key]["nombre"];
            $aMensaje = array("texto" => "¡Bienvenid@ $nombre a la fiesta!", 
                              "estado" => "success");
        }else{
            $aMensaje = array("texto" => "No se encuentra en la lista de invitados.", 
                              "estado" => "danger");
        }
    } else if (isset($_POST["btnVip"])) {
        $respuesta = trim($_POST["txtPregunta"]);
        if($respuesta=="verde"){
            $aMensaje = array("texto" => "Su código de acceso es " . rand(1111,9999), "estado" => "success");
        } else {
            $aMensaje = array("texto" => "Ud. no tiene pase VIP", "estado" => "danger");
        }
    }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario Invitados</title>
    <!--CSS-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="fontawesome/css/fontawesome.min.css">
</head>
<body>
<main class="container">
        <div class="row">
            <div class="col-12 pt-5 pb-3 text-center">
                <h1>Lista de Invitados<br></h1>
            </div>
        </div>
        <div class="col-12">
            <p>Complete el siguiente formulario:</p>
        </div>
        <div class="col-6">
            <form method="POST" action="">
                <div class="row">
                    <div class="col-12">
                        <p>Ingrese el DNI:<p>
                        <input type="text" name="txtDNI" class="form-control">
                        <input type="submit" name="btnProcesar" value="Verificar invitado" class="btn-primary">
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 mb-3">
                        <p>Ingresa el código secreto para el pase VIP:<p>
                        <input type="text" name="txtPregunta" class="form-control">
                        <input type="submit" name="btnVip" value="Verificar código" class="btn-primary">
                    </div>
                </div>
            </form>
        </div>
        <?php if(isset($aMensaje)): ?>
        <div class="col-12">
            <div class="alert alert-<?php echo $aMensaje["estado"]; ?>" role="alert">
                <?php echo $aMensaje["texto"]; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
	</main>

</body>
</html>